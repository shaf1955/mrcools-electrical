# Eric's Electrical Services

Initial responsive one-page website for Eric's electrical and drywall services.

## Current business details
- Phone: (215) 554-4309
- Service area: Philadelphia, New Jersey, New York
- Email: none

## To customize later
Replace the photo placeholders, Eric's biography, certifications/experience, and service-area details if desired.

## GitHub Pages
Upload the files to the repository root and enable GitHub Pages from Settings > Pages, using the main branch and root folder.
